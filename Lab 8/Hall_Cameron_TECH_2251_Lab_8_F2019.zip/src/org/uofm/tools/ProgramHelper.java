package org.uofm.tools;

public class ProgramHelper 
{
	
	public static void ProgramDescription()
	{
		System.out.println("This program demonstrates the use");
		System.out.println("of inheritance within the Java framework");
	}
	
	public static void DeveloperInformation ()
	{
		System.out.println();
		System.out.println("This program was written by: Cameron Hall");
		System.out.println("Laboratory Exercise 8");
		System.out.println("TECH 2251");
		System.out.println("Advanced Programming Technology");
		System.out.println("Fall 2019");
		System.out.println("The University of Memphis");
	}

}
