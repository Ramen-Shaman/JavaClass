package org.uofm.tools;

public class ElementaryArithmetic
{
	public double AddTwoNumbers(int a, int b)
	{
		double result = 0;
		result = a + b;
		return(result);
	}
	
	public double SubtractTwoNumbers(int a, int b)
	{
		double result = 0;
		result = a - b;
		return(result);
	}

	public double MultiplyTwoNumbers(int a, int b)
	{
		double result = 0;
		result = a * b;
		return(result);
	}
	
	public double DivideTwoNumbers(int a, int b)
	{
		double result = 0;
		result = a / b;
		return(result);
	}
}
